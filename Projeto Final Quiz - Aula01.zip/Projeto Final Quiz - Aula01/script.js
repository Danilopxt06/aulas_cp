const perguntas = [
    {
        texto: "1) Qual desses navegadores NÃO é um exemplo de browser?",
        opcoes: ["Chrome", "Firefox", "VS Code", "Edge"],
        correta: 2
    },
    {
        texto: "2) Qual tag HTML é usada para o título principal da página?",
        opcoes: ["<p>", "<h1>", "<title>", "<main>"],
        correta: 1
    },
    {
        texto: "3) Qual propriedade CSS muda a cor de fundo?",
        opcoes: ["color", "background-color", "font-style", "border"],
        correta: 1
    },
    {
        texto: "4) Qual destas extensões é de um arquivo JavaScript?",
        opcoes: [".js", ".css", ".html", ".json"],
        correta: 0
    },
    {
        texto: "5) Em JavaScript, como mostramos algo no console?",
        opcoes: ["console.show()", "log.console()", "console.log()", "print()"],
        correta: 2
    }



]