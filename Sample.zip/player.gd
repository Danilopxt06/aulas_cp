extends CharacterBody3D

@export var speed: float = 5.0
@export var jump_force: float = 4.5
@export var gravity: float = 9.8
@export var view: Node3D

var input_dir: Vector2
var direction: Vector3


func _physics_process(delta):
	handle_input(delta)
	apply_gravity(delta)
	jump()
	handle_animations()
	move_and_slide()


func handle_input(delta):
	input_dir = Input.get_vector("move_left", "move_right", "move_forward", "move_back")

	var basis = view.global_transform.basis

	direction = (basis.x * input_dir.x + basis.z * input_dir.y)
	direction.y = 0
	direction = direction.normalized()

	if direction != Vector3.ZERO:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
	else:
		velocity.x = move_toward(velocity.x, 0, speed)
		velocity.z = move_toward(velocity.z, 0, speed)


func apply_gravity(delta):
	if not is_on_floor():
		velocity.y -= gravity * delta


func jump():
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = jump_force


func handle_animations():
	# coloque aqui animações se tiver AnimationPlayer ou AnimationTree
	pass
