extends Node3D

@export var target: CharacterBody3D
@export var distance := 6.0
@export var height := 3.0
@export var rotation_speed := 2.0

var rotation_input := 0.0

func _process(delta):

	if target == null:
		return

	rotation_input = 0

	if Input.is_action_pressed("camera_left"):
		rotation_input += 1

	if Input.is_action_pressed("camera_right"):
		rotation_input -= 1

	rotate_y(rotation_input * rotation_speed * delta)

	var target_position = target.global_transform.origin
	var offset = Vector3(0, height, distance)

	var rotated_offset = offset.rotated(Vector3.UP, rotation.y)

	global_transform.origin = target_position + rotated_offset

	look_at(target_position, Vector3.UP)
