extends CharacterBody2D

const SPEED = 400.0
const JUMP_VELOCITY = -900.0

var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")

@onready var sprite_2d: AnimatedSprite2D = $Sprite2D

func _physics_process(delta):

	# Gravidade
	if not is_on_floor():
		velocity.y += gravity * delta
		sprite_2d.animation = "jump"

	# Pulo
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Movimento horizontal
	var direction := Input.get_axis("left", "right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	# Animação de corrida ou idle
	if is_on_floor():
		if abs(velocity.x) > 1:
			sprite_2d.animation = "run"
		else:
			sprite_2d.animation = "default"

	# Virar sprite
	if velocity.x < 0:
		sprite_2d.flip_h = true
	elif velocity.x > 0:
		sprite_2d.flip_h = false

	move_and_slide()
