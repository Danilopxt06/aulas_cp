
const perguntas=[
[
"1 - Em um trabalho em grupo, você costuma ser quem?",
"Assume a liderança e resolve as partes difíceis",
"Mantém o grupo organizado e focado",
"Ajuda todos e não desiste",
"Resolve de um jeito diferente do padrão"
],
[
"2 - Qual é sua maior qualidade?",
"Alto desempenho",
"Confiabilidade",
"Persistência",
"Versatilidade"
],
[
"3 - Quando surge um desafio, você:",
"Age rápido e entrega resultados",
"Analisa antes de agir",
"Insiste até conseguir",
"Usa criatividade para resolver"
],
[
"4 - Como as pessoas te enxergam?",
"Diferenciado",
"Essencial no dia a dia",
"Determinado",
"Único"
]
];

const resultados=[
{
    texto:"👟 Nike – Desempenho e destaque",
    img:"imagens/nike.png"
},
{
    texto:"💻 Windows – Base e confiabilidade",
    img:"imagens/windows.png"
},
{
    texto:"🔥 Tanjiro – Persistência e empatia",
    img:"imagens/tanjiro.png"
},
{
    texto:"⚔️ Satoru Gojou – Poder e versatilidade",
    img:"imagens/gojou.png"
}
];

let i=0;
let pontos=[0,0,0,0];

function iniciar(){
    inicio.classList.remove("ativa");
    quiz.classList.add("ativa");
    mostrar();
}

function mostrar(){
    pergunta.innerText=perguntas[i][0];
    o0.innerText=perguntas[i][1];
    o1.innerText=perguntas[i][2];
    o2.innerText=perguntas[i][3];
    o3.innerText=perguntas[i][4];
    document.querySelectorAll("input").forEach(x=>x.checked=false);
    aviso.innerText="";
}

function prox(){
    const sel=document.querySelector("input:checked");
    if(!sel){
        aviso.innerText="Escolha uma opção";
        return;
    }
    pontos[sel.value]++;
    i++;
    i<perguntas.length ? mostrar() : fimQuiz();
}

function fimQuiz(){
    quiz.classList.remove("ativa");
    fim.classList.add("ativa");

    const v = pontos.indexOf(Math.max(...pontos));
    res.innerText = resultados[v].texto;
    imgRes.src = resultados[v].img;
}